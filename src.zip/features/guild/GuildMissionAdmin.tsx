import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { TeacherShell } from '@/components/teacher/TeacherShell';
import { EmptyState, LoadingSpinner, Modal } from '@/components/shared/components';
import { supabase } from '@/lib/supabase/client';
import { guild3TeacherRpc, guild3RpcError, type Guild3MissionDetail, type Guild3MissionListItem } from '@/lib/rpc/guild3_rpc';
import { guild4TeacherRpc, guild4RpcError } from '@/lib/rpc/guild4_rpc';
import { useToastStore } from '@/stores/ui_store';
import type { ReactNode } from 'react';

const fmt=(v?:string|null)=>v?new Intl.DateTimeFormat('ko-KR',{year:'numeric',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'}).format(new Date(v)):'-';
const safeExternalHref=(value:unknown)=>{const raw=String(value??'').trim();if(!raw)return null;const candidate=/^https?:\/\//i.test(raw)?raw:`https://${raw}`;try{const url=new URL(candidate);return url.protocol==='http:'||url.protocol==='https:'?url.href:null;}catch{return null;}};
const stateStyle:Record<string,string>={DRAFT:'text-warning bg-warning/10',ACTIVE:'text-success bg-success/10',CLOSED:'text-bv bg-bv/10',FINALIZED:'text-gold bg-gold/10',CANCELLED:'text-text-muted bg-bg-deep',VOIDED:'text-danger bg-danger/10'};
const stateKo:Record<string,string>={DRAFT:'초안',ACTIVE:'진행 중',CLOSED:'마감/채점',FINALIZED:'확정',CANCELLED:'취소',VOIDED:'무효'};

type ActionResult={success:true;data:unknown}|{success:false;error:string};

export default function GuildMissionAdmin(){
  const qc=useQueryClient(); const show=useToastStore(s=>s.show); const [selected,setSelected]=useState<number|null>(null); const [createOpen,setCreateOpen]=useState(false);
  const listQ=useQuery({queryKey:['guild3-teacher-list'],queryFn:async()=>{const r=await guild3TeacherRpc.list(supabase);if(!r.success)throw new Error(guild3RpcError(r));return r.data;}});
  useEffect(()=>{if(selected===null&&listQ.data?.length)setSelected(listQ.data[0].mission_id)},[selected,listQ.data]);
  const detailQ=useQuery({queryKey:['guild3-teacher-detail',selected],enabled:selected!==null,queryFn:async()=>{const r=await guild3TeacherRpc.detail(supabase,{p_mission_id:selected!});if(!r.success)throw new Error(guild3RpcError(r));return r.data;}});
  const refresh=async()=>{await Promise.all([qc.invalidateQueries({queryKey:['guild3-teacher-list']}),qc.invalidateQueries({queryKey:['guild3-teacher-detail',selected]})]);};
  const act=useMutation({mutationFn:async(fn:()=>Promise<ActionResult>)=>{const r=await fn();if('error' in r)throw new Error(r.error);return r.data;},onSuccess:async()=>{show({title:'미션 상태를 반영했어요',variant:'success'});await refresh();},onError:e=>show({title:'미션 작업 오류',description:(e as Error).message,variant:'error',duration:6000})});
  const run=(promise:Promise<any>)=>act.mutateAsync(async()=>{const r=await promise;return r.success?{success:true,data:r.data}:{success:false,error:guild3RpcError(r)}});
  const syncG4=useMutation({mutationFn:async()=>{const r=await guild4TeacherRpc.sync(supabase);if(!r.success)throw new Error(guild4RpcError(r));return r.data;},onSuccess:data=>{show({title:'Guild3 → G4 동기화 완료',description:`새 round ${data.created}개 · 기존 ${data.already_existing}개`,variant:'success'});void qc.invalidateQueries({queryKey:['guild4-teacher-list']});},onError:e=>show({title:'Guild4 동기화 실패',description:(e as Error).message,variant:'error',duration:7000})});
  return <TeacherShell><div className="space-y-5">
    <div className="flex flex-wrap items-center justify-between gap-3"><div><div className="text-xs text-text-muted font-black">Guild 3</div><h1 className="font-display text-2xl text-brand-gradient">공식 길드 미션</h1><p className="text-sm text-text-secondary mt-1">미션 공개부터 개인 기여도 /300 반영까지 관리합니다.</p></div><div className="flex flex-wrap gap-2"><Link to="/teacher/guild" className="btn-secondary">← 길드 운영</Link><button className="btn-secondary" disabled={syncG4.isPending} onClick={()=>syncG4.mutate()}>{syncG4.isPending?'G4 동기화 중...':'🔄 Guild3 → G4 동기화'}</button><Link to="/teacher/guild/peer-review" className="btn-secondary">🤝 G4 관리</Link><button className="btn-primary" onClick={()=>setCreateOpen(true)}>＋ 미션 만들기</button></div></div>
    <div className="grid lg:grid-cols-[320px_minmax(0,1fr)] gap-4">
      <section className="glass-card p-3 h-fit"><h2 className="font-black px-1 mb-2">미션 목록</h2>{listQ.isLoading?<div className="py-10 flex justify-center"><LoadingSpinner/></div>:listQ.error?<p className="text-danger text-sm p-3">{(listQ.error as Error).message}</p>:(listQ.data??[]).length===0?<EmptyState emoji="🗺️" title="미션이 없습니다"/>:<div className="space-y-2">{(listQ.data??[]).map(m=><button key={m.mission_id} onClick={()=>setSelected(m.mission_id)} className={`w-full text-left rounded-card-md border p-3 transition ${selected===m.mission_id?'border-bv bg-bv/10':'border-line bg-bg-deep hover:border-bv/40'}`}><div className="flex items-center justify-between gap-2"><span className="font-black truncate">{m.title}</span><StateBadge state={m.lifecycle_state}/></div><div className="text-2xs text-text-muted mt-2">{m.contribution_year_month} · 가중치 {m.weight} · {fmt(m.due_at)}</div>{m.lifecycle_state==='CLOSED'&&<div className="text-2xs text-warning mt-1">미판정 {m.unresolved_instance_count} · 미등급 {m.ungraded_participant_count}</div>}</button>)}</div>}</section>
      <section className="glass-card min-h-[420px]">{selected===null?<EmptyState emoji="🗺️" title="미션을 선택하세요"/>:detailQ.isLoading?<div className="py-24 flex justify-center"><LoadingSpinner size="lg"/></div>:detailQ.error?<div className="p-5 text-danger">{(detailQ.error as Error).message}</div>:detailQ.data?<MissionDetailPanel detail={detailQ.data} busy={act.isPending} run={run} refresh={refresh}/>:null}</section>
    </div>
  </div>{createOpen&&<MissionEditor onClose={()=>setCreateOpen(false)} onSaved={id=>{setCreateOpen(false);setSelected(id);refresh();}}/>}</TeacherShell>;
}

function MissionDetailPanel({detail,busy,run,refresh}:{detail:Guild3MissionDetail;busy:boolean;run:(p:Promise<any>)=>Promise<unknown>;refresh:()=>void}){
  const m=detail.mission; const [editOpen,setEditOpen]=useState(false); const state=String(m.lifecycle_state);
  const reason=(message:string)=>window.prompt(message)?.trim()||'';
  const activityDeadlineMs=new Date(String(m.activity_record_due_at??'')).getTime();
  const finalizingBeforeActivityDeadline=state==='CLOSED'&&Number.isFinite(activityDeadlineMs)&&Date.now()<activityDeadlineMs;
  const publish=()=>{if(window.confirm('이 미션을 공개하면 참가자/길드 snapshot과 점수 핵심 설정이 고정됩니다. 공개할까요?'))void run(guild3TeacherRpc.publish(supabase,{p_mission_id:Number(m.id)})).catch(()=>undefined);};
  const close=()=>{const r=reason('조기 마감 또는 일반 마감 사유를 입력하세요.');if(r)void run(guild3TeacherRpc.close(supabase,{p_mission_id:Number(m.id),p_reason:r})).catch(()=>undefined);};
  const reopen=()=>{const r=reason('다시 ACTIVE로 여는 사유를 입력하세요.');if(r)void run(guild3TeacherRpc.reopen(supabase,{p_mission_id:Number(m.id),p_reason:r})).catch(()=>undefined);};
  const cancel=()=>{const r=reason('미션 취소 사유를 입력하세요.');if(r&&window.confirm('취소하면 일반 흐름에서는 되돌릴 수 없습니다. 계속할까요?'))void run(guild3TeacherRpc.cancel(supabase,{p_mission_id:Number(m.id),p_reason:r})).catch(()=>undefined);};
  const finalize=()=>{const r=window.prompt('필수 제출 누락을 예외로 확정해야 할 때만 사유를 입력하세요. 없으면 빈칸으로 확인하세요.')??null;if(r===null)return;const warning=finalizingBeforeActivityDeadline?`활동 기록 마감(${fmt(m.activity_record_due_at)}) 전입니다. 지금 최종 확정하면 학생의 남은 활동 기록 작성/수정 기회가 즉시 종료됩니다. 그래도 확정할까요?`:'점수와 Guild 4 opening을 공식 확정할까요?';if(window.confirm(warning))void run(guild3TeacherRpc.finalize(supabase,{p_mission_id:Number(m.id),p_missing_required_submission_override_reason:r.trim()||null})).catch(()=>undefined);};
  const unfinalize=()=>{const r=reason('최종 확정을 취소하고 CLOSED(마감/채점) 상태로 되돌리는 사유를 입력하세요.');if(r&&window.confirm('기존 제출·활동 기록·판정·등급 이력은 모두 보존됩니다. 아직 Guild4 round가 생성되지 않은 경우에만 확정 취소가 가능합니다. 계속할까요?'))void run(guild3TeacherRpc.unfinalize(supabase,{p_mission_id:Number(m.id),p_reason:r})).catch(()=>undefined);};
  const voidMission=()=>{const r=reason('미션 자체를 무효(VOID) 처리해야 하는 명확한 사유를 입력하세요.');if(r&&window.confirm('VOID는 단순한 확정 취소가 아닙니다. 이 미션 자체를 월간 점수원에서 제외하고 Guild4 opening도 무효화합니다. 정말 VOID 처리할까요?'))void run(guild3TeacherRpc.voidMission(supabase,{p_mission_id:Number(m.id),p_reason:r})).catch(()=>undefined);};
  const restoreVoided=()=>{const r=reason('실수로 VOID한 미션을 다시 FINALIZED 상태로 복구하는 사유를 입력하세요.');if(r&&window.confirm('Guild4 round가 아직 생성되지 않은 VOID 미션만 자동 복구할 수 있습니다. 복구할까요?'))void run(guild3TeacherRpc.restoreVoided(supabase,{p_mission_id:Number(m.id),p_reason:r})).catch(()=>undefined);};
  return <div className="p-5 space-y-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><StateBadge state={state}/><h2 className="font-display text-2xl mt-2">{m.title}</h2><p className="text-xs text-text-muted mt-2">{m.contribution_year_month} · weight {m.weight} · {m.submission_scope}/{m.submission_requirement} · Peer {m.peer_review_required?'ON':'OFF'}</p></div><div className="flex flex-wrap gap-2">{state==='DRAFT'&&<><button className="btn-secondary" disabled={busy} onClick={()=>setEditOpen(true)}>초안 수정</button><button className="btn-primary" disabled={busy} onClick={publish}>공개</button><button className="btn-danger" disabled={busy} onClick={cancel}>취소</button></>}{state==='ACTIVE'&&<><button className="btn-secondary" disabled={busy} onClick={()=>setEditOpen(true)}>표시/마감 수정</button><button className="btn-primary" disabled={busy} onClick={close}>마감</button><button className="btn-danger" disabled={busy} onClick={cancel}>취소</button></>}{state==='CLOSED'&&<><button className="btn-secondary" disabled={busy} onClick={()=>setEditOpen(true)}>표시/마감 수정</button><button className="btn-secondary" disabled={busy} onClick={reopen}>다시 열기</button><button className="btn-secondary" disabled={busy} onClick={()=>void run(guild3TeacherRpc.autoF(supabase,{p_mission_id:Number(m.id)})).catch(()=>undefined)}>미활동 F 일괄</button><button className="btn-primary" disabled={busy} title={finalizingBeforeActivityDeadline?'지금 확정하면 남은 활동 기록 작성/수정이 즉시 종료됩니다.':undefined} onClick={finalize}>최종 확정</button><button className="btn-danger" disabled={busy} onClick={cancel}>취소</button></>}{state==='FINALIZED'&&<><button className="btn-secondary" disabled={busy} onClick={unfinalize}>↩ 최종 확정 취소</button><button className="btn-danger" disabled={busy} onClick={voidMission}>🚫 미션 무효화 (VOID)</button></>}{state==='VOIDED'&&<button className="btn-secondary" disabled={busy} onClick={restoreVoided}>↩ VOID 취소</button>}</div></div>
    {state==='FINALIZED'&&<div className="rounded-card-md border border-bv/30 bg-bv/10 px-3 py-3 text-sm text-bv"><b>수정이 필요한 경우</b><div className="mt-1 text-xs text-text-secondary">Guild4 round 생성 전이라면 <b>최종 확정 취소</b>로 CLOSED 상태에 돌아가 기록/채점을 다시 정리할 수 있습니다. 이미 Guild4 round가 시작됐다면 확정 취소 대신 아래 CLEARED/FAILED 및 S/A/B/C/F 정정 기능을 사용해 이력을 보존합니다.</div></div>}
    {state==='VOIDED'&&<div className="rounded-card-md border border-danger/30 bg-danger/10 px-3 py-3 text-sm text-danger"><b>이 미션은 VOID 상태입니다.</b><div className="mt-1 text-xs">VOID는 미션 자체를 점수원에서 제외하는 강한 무효 처리입니다. 실수로 눌렀고 Guild4 round가 아직 생성되지 않았다면 <b>VOID 취소</b>로 FINALIZED 상태를 복구할 수 있습니다.</div></div>}
    <div className="grid md:grid-cols-2 gap-3"><TextBox title="학생 공개 설명" text={m.description}/><TextBox title="학생 성공 조건" text={m.student_success_criteria}/><TextBox title="교사 운영 메모" text={m.teacher_guidance}/><div className="rounded-card-md border border-line bg-bg-deep p-3 text-sm"><div className="text-xs font-black text-text-muted">마감</div><div className="mt-1">결과 제출 {fmt(m.due_at)}</div><div>활동 기록 {fmt(m.activity_record_due_at)}</div></div></div>
    {finalizingBeforeActivityDeadline&&<div className="rounded-card-md border border-warning/40 bg-warning/10 px-3 py-3 text-sm text-warning"><b>활동 기록 마감 전 조기 확정 가능</b><div className="mt-1 text-xs">현재 활동 기록 마감은 <b>{fmt(m.activity_record_due_at)}</b>입니다. 최종 확정을 누르면 이 시각을 기다리지 않고 즉시 FINALIZED되며, 그 순간부터 학생은 활동 기록을 더 작성하거나 수정할 수 없습니다.</div></div>}
    {detail.instances.length>0&&<div className="space-y-3"><h3 className="font-display text-lg">길드별 판정 · 개인 등급</h3>{detail.instances.map(row=><InstancePanel key={String(row.instance.id)} row={row} missionState={state} busy={busy} run={run}/>)}</div>}
    {detail.audit_history.length>0&&<details className="rounded-card-md border border-line bg-bg-deep"><summary className="cursor-pointer p-3 font-black text-sm">감사 이력 {detail.audit_history.length}건</summary><div className="border-t border-line p-3 space-y-2 max-h-72 overflow-y-auto">{detail.audit_history.map((a:any)=><div key={a.id} className="text-xs"><b>{a.event_type??a.action_type??'EVENT'}</b> · {fmt(a.occurred_at)}{a.reason&&<span className="text-text-secondary"> · {a.reason}</span>}</div>)}</div></details>}
    {editOpen&&<MissionEditor mission={m} presentationMode={state!=='DRAFT'} onClose={()=>setEditOpen(false)} onSaved={()=>{setEditOpen(false);void refresh();}}/>}
  </div>;
}

function InstancePanel({
  row,
  missionState,
  busy,
  run,
}: {
  row: Guild3MissionDetail['instances'][number];
  missionState: string;
  busy: boolean;
  run: (p: Promise<any>) => Promise<unknown>;
}) {
  const i = row.instance;
  const canJudge = missionState === 'CLOSED';
  const correction = missionState === 'FINALIZED';

  const guildName =
    row.participants?.[0]?.participant?.guild_name_at_snapshot?.trim() ||
    `길드 #${i.guild_id}`;

  const [displayResult, setDisplayResult] = useState(
    String(i.current_guild_result ?? 'UNDECIDED'),
  );

  useEffect(() => {
    setDisplayResult(String(i.current_guild_result ?? 'UNDECIDED'));
  }, [i.current_guild_result]);

  const setResult = async (result: 'CLEARED' | 'FAILED') => {
    const r =
      window.prompt(
        correction
          ? '공식 결과 정정 사유를 입력하세요.'
          : '판정 메모 (선택)',
      ) ?? null;

    if (r === null) return;

    try {
      await run(
        correction
          ? guild3TeacherRpc.correctResult(supabase, {
              p_mission_instance_id: Number(i.id),
              p_guild_result: result,
              p_reason: r.trim() || '공식 결과 정정',
            })
          : guild3TeacherRpc.setResult(supabase, {
              p_mission_instance_id: Number(i.id),
              p_guild_result: result,
              p_reason: r.trim() || null,
            }),
      );

      setDisplayResult(result);
    } catch {
      return;
    }
  };

  const setNote = () => {
    const note = window.prompt(
      '이 길드에만 보일 특별 안내를 입력하세요. 빈칸이면 삭제합니다.',
      String(i.special_rule_note ?? ''),
    );

    if (note !== null) {
      void run(
        guild3TeacherRpc.setNote(supabase, {
          p_mission_instance_id: Number(i.id),
          p_special_rule_note: note.trim() || null,
        }),
      ).catch(() => undefined);
    }
  };

  return (
    <div className="rounded-card-md border border-line bg-bg-deep overflow-hidden">
      <div className="p-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <b>{guildName}</b>

          <span
            className={`ml-2 inline-flex rounded-full px-2 py-1 text-2xs font-black ${
              displayResult === 'CLEARED'
                ? 'bg-success/15 text-success'
                : displayResult === 'FAILED'
                  ? 'bg-danger/15 text-danger'
                  : 'bg-bg-card text-text-muted'
            }`}
          >
            현재 {displayResult}
          </span>
        </div>

        <div className="flex gap-2">
          {['ACTIVE', 'CLOSED'].includes(missionState) && (
            <button
              className="btn-secondary text-xs"
              disabled={busy}
              onClick={setNote}
            >
              특별 안내
            </button>
          )}

          {(canJudge || correction) && (
            <>
              <button
                aria-pressed={displayResult === 'CLEARED'}
                className={`text-xs rounded-card-md border px-4 py-2 font-black transition ${
                  displayResult === 'CLEARED'
                    ? 'border-success bg-success/20 text-success ring-2 ring-success/30'
                    : 'border-line bg-bg-card text-text-primary hover:border-success/50'
                }`}
                disabled={busy}
                onClick={() => void setResult('CLEARED')}
              >
                {displayResult === 'CLEARED' ? '✓ CLEARED' : '✅ CLEARED'}
              </button>

              <button
                aria-pressed={displayResult === 'FAILED'}
                className={`text-xs rounded-card-md border px-4 py-2 font-black transition ${
                  displayResult === 'FAILED'
                    ? 'border-danger bg-danger/20 text-danger ring-2 ring-danger/30'
                    : 'border-line bg-bg-card text-text-primary hover:border-danger/50'
                }`}
                disabled={busy}
                onClick={() => void setResult('FAILED')}
              >
                {displayResult === 'FAILED' ? '✓ FAILED' : '❌ FAILED'}
              </button>
            </>
          )}
        </div>
      </div>

      {i.special_rule_note && (
        <div className="px-3 pb-3 text-xs text-warning">
          특별 안내: {i.special_rule_note}
        </div>
      )}

      <div className="border-t border-line divide-y divide-line">
        {row.participants.map((p) => (
          <ParticipantRow
            key={String(p.participant.id)}
            item={p}
            missionState={missionState}
            busy={busy}
            run={run}
          />
        ))}
      </div>

      {row.submissions.length > 0 && (
        <details className="border-t border-line">
          <summary className="p-3 cursor-pointer text-xs font-black">
            제출 이력 {row.submissions.length}건
          </summary>

          <div className="px-3 pb-3 space-y-2">
            {row.submissions.map((s: any) => {
  // BRAND_PATCH_GUILD3_SUBMITTER_NAME_V3
  const submitterName =
    row.participants.find(
      (p: any) =>
        Number(p?.participant?.student_id) === Number(s.submitted_by_student_id),
    )?.participant?.student_name_at_snapshot?.trim() ||
    ('Student #' + String(s.submitted_by_student_id));
              const href = safeExternalHref(s.reference_url);

              return (
                <div key={s.id} className="rounded bg-bg-card p-2 text-xs">
                  <b>
                    {submitterName} &middot; {s.submission_scope} · revision {s.revision_number}
                  </b>

                  <div className="mt-1 whitespace-pre-wrap">{s.content}</div>

                  {s.reference_url &&
                    (href ? (
                      <a
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-bv mt-1 inline-flex max-w-full items-center gap-1 break-all underline underline-offset-2 hover:opacity-80"
                      >
                        🔗 {s.reference_url}
                        <span className="shrink-0">↗</span>
                      </a>
                    ) : (
                      <div className="text-warning mt-1 break-all">
                        참고 링크 형식을 확인하세요: {s.reference_url}
                      </div>
                    ))}
                </div>
              );
            })}
          </div>
        </details>
      )}
    </div>
  );
}

function ParticipantRow({item,missionState,busy,run}:{item:any;missionState:string;busy:boolean;run:(p:Promise<any>)=>Promise<unknown>}){
  const p=item.participant; const backendGrade=String(item.latest_grade_event?.grade??''); const canGrade=missionState==='CLOSED'||missionState==='FINALIZED';
  const [displayGrade,setDisplayGrade]=useState(backendGrade);
  useEffect(()=>setDisplayGrade(backendGrade),[backendGrade]);
  const grade=async(g:'S'|'A'|'B'|'C'|'F')=>{let override:string|null=null;if(!item.latest_activity_record&&g!=='F'){override=window.prompt('활동 기록 없이 F보다 높은 등급을 주는 예외 사유를 입력하세요.')?.trim()||'';if(!override)return;}try{if(missionState==='FINALIZED'){const correction=window.prompt('확정 후 등급 정정 사유를 입력하세요.')?.trim()||'';if(!correction)return;await run(guild3TeacherRpc.correctGrade(supabase,{p_participant_id:Number(p.id),p_grade:g,p_override_reason:override,p_correction_reason:correction}));}else await run(guild3TeacherRpc.setGrade(supabase,{p_participant_id:Number(p.id),p_grade:g,p_override_reason:override}));setDisplayGrade(g);}catch{return;}};
  return <div className="p-3"><div className="flex flex-wrap items-center justify-between gap-2"><div><b className="text-sm">{p.student_name_at_snapshot}</b>{displayGrade?<span className="ml-2 inline-flex rounded-full bg-gold/15 px-2 py-1 text-2xs font-black text-gold">현재 등급 {displayGrade}</span>:<span className="text-xs text-text-muted ml-2">현재 등급 -</span>}</div>{canGrade&&<div className="flex gap-1">{(['S','A','B','C','F'] as const).map(g=><button key={g} aria-pressed={displayGrade===g} disabled={busy} onClick={()=>void grade(g)} className={`min-w-9 h-9 rounded border px-2 text-xs font-black transition ${displayGrade===g?'border-gold bg-gold text-bg-deep ring-2 ring-gold/30':'border-line bg-bg-card hover:border-gold/50'}`}>{displayGrade===g?`✓ ${g}`:g}</button>)}</div>}</div><div className="mt-2 text-xs text-text-secondary">{item.latest_activity_record?<><b className="text-text-primary">활동:</b> {item.latest_activity_record.content}</>:<span className="text-warning">활동 기록 없음 → 기본 F 대상</span>}</div></div>;
}

function MissionEditor({mission,onClose,onSaved,presentationMode=false}:{mission?:Record<string,any>;onClose:()=>void;onSaved:(id?:number)=>void;presentationMode?:boolean}){
  const show=useToastStore(s=>s.show); const [busy,setBusy]=useState(false); const [saveMessage,setSaveMessage]=useState<{kind:'info'|'error';text:string}|null>(null);
  const pad2=(value:number)=>String(value).padStart(2,'0');
  const hourOptions=Array.from({length:24},(_,i)=>pad2(i));
  const minuteOptions=Array.from({length:60},(_,i)=>pad2(i));
  const toLocalParts=(v?:string)=>{if(!v)return{date:'',hour:'',minute:''};const d=new Date(v);const x=new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString();return{date:x.slice(0,10),hour:x.slice(11,13),minute:x.slice(14,16)}};
  const dueLocal=toLocalParts(mission?.due_at);
  const activityDueLocal=toLocalParts(mission?.activity_record_due_at);
  const [f,setF]=useState({month:String(mission?.contribution_year_month??new Date().toISOString().slice(0,7)),title:String(mission?.title??''),teaserVisible:Boolean(mission?.teaser_visible),teaserTitle:String(mission?.teaser_title??''),description:String(mission?.description??''),criteria:String(mission?.student_success_criteria??''),guidance:String(mission?.teacher_guidance??''),weight:Number(mission?.weight??1),scope:String(mission?.submission_scope??'GUILD'),requirement:String(mission?.submission_requirement??'REQUIRED'),dueDate:dueLocal.date,dueHour:dueLocal.hour,dueMinute:dueLocal.minute,activityDueDate:activityDueLocal.date,activityDueHour:activityDueLocal.hour,activityDueMinute:activityDueLocal.minute,peer:Boolean(mission?.peer_review_required??true),reason:''});
  const set=(k:string,v:any)=>setF(x=>({...x,[k]:v}));
  const validCombo=f.scope==='NONE'?f.requirement==='NONE':f.requirement!=='NONE';
  const dueTimeComplete=Boolean(f.dueHour&&f.dueMinute);
  const dueLocalValue=f.dueDate&&dueTimeComplete?`${f.dueDate}T${f.dueHour}:${f.dueMinute}`:'';
  const activityDueHasAny=Boolean(f.activityDueDate||f.activityDueHour||f.activityDueMinute);
  const activityDueComplete=Boolean(f.activityDueDate&&f.activityDueHour&&f.activityDueMinute);
  const activityDueLocalValue=activityDueComplete?`${f.activityDueDate}T${f.activityDueHour}:${f.activityDueMinute}`:'';
  const missing:string[]=[];
  if(!f.title.trim()) missing.push('미션 제목');
  if(!f.dueDate) missing.push('결과 제출 마감 날짜');
  if(!dueTimeComplete) missing.push('결과 제출 마감 시간');
  if(activityDueHasAny&&!activityDueComplete) missing.push('활동 기록 마감 날짜/시간');
  if(!validCombo) missing.push('제출 단위/제출 요구 조합');
  const save=async()=>{
    if(busy) return;
    if(missing.length){
      const message=`${missing.join(', ')} 항목을 확인해주세요.`;
      setSaveMessage({kind:'error',text:message});
      show({title:'저장 전 확인이 필요해요',description:message,variant:'warning',duration:5000});
      return;
    }
    setSaveMessage({kind:'info',text:'미션을 저장하고 있어요…'});
    setBusy(true);
    try{
      let r:any;
      if(presentationMode&&mission){
        r=await guild3TeacherRpc.updatePresentation(supabase,{p_mission_id:Number(mission.id),p_title:f.title.trim(),p_teaser_visible:f.teaserVisible,p_teaser_title:f.teaserTitle.trim()||null,p_description:f.description.trim()||null,p_student_success_criteria:f.criteria.trim()||null,p_teacher_guidance:f.guidance.trim()||null,p_due_at:new Date(dueLocalValue).toISOString(),p_activity_record_due_at:new Date(activityDueLocalValue||dueLocalValue).toISOString(),p_reason:f.reason.trim()||'교사 표시/마감 정보 수정'});
      }else{
        const base={p_contribution_year_month:f.month,p_title:f.title.trim(),p_teaser_visible:f.teaserVisible,p_teaser_title:f.teaserTitle.trim()||null,p_description:f.description.trim()||null,p_student_success_criteria:f.criteria.trim()||null,p_teacher_guidance:f.guidance.trim()||null,p_weight:f.weight,p_submission_scope:f.scope as any,p_submission_requirement:f.requirement as any,p_due_at:new Date(dueLocalValue).toISOString(),p_activity_record_due_at:activityDueLocalValue?new Date(activityDueLocalValue).toISOString():null,p_peer_review_required:f.peer};
        r=mission?await guild3TeacherRpc.updateDraft(supabase,{p_mission_id:Number(mission.id),...base}):await guild3TeacherRpc.create(supabase,base);
      }
      if(!r.success) throw new Error(guild3RpcError(r));
      setSaveMessage(null);
      show({title:mission?'미션 수정 완료':'미션 생성 완료',variant:'success'});
      const id=Number(r.data?.mission_id??mission?.id??0);
      onSaved(id||undefined);
    }catch(e){
      const message=e instanceof Error?e.message:String(e);
      setSaveMessage({kind:'error',text:message});
      show({title:'저장 실패',description:message,variant:'error',duration:6000});
    }finally{setBusy(false)}
  };
  return <Modal isOpen onClose={onClose} title={mission?(presentationMode?'미션 표시/마감 수정':'미션 초안 수정'):'새 공식 미션'} emoji="🗺️" size="lg"><div className="space-y-3">{!presentationMode&&<div className="grid grid-cols-2 gap-3"><Field label="기여 월"><input type="month" className="input-field w-full" value={f.month} onChange={e=>set('month',e.target.value)}/></Field><Field label="가중치"><input type="number" min="0.1" step="0.1" className="input-field w-full" value={f.weight} onChange={e=>set('weight',Number(e.target.value))}/></Field></div>}<Field label="미션 제목"><input className="input-field w-full" value={f.title} onChange={e=>set('title',e.target.value)}/></Field><label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={f.teaserVisible} onChange={e=>set('teaserVisible',e.target.checked)}/> 공개 전 티저 제목 노출</label>{f.teaserVisible&&<Field label="티저 제목"><input className="input-field w-full" value={f.teaserTitle} onChange={e=>set('teaserTitle',e.target.value)}/></Field>}<Field label="학생 공개 설명"><textarea className="input-field w-full min-h-24" value={f.description} onChange={e=>set('description',e.target.value)}/></Field><Field label="학생 성공 조건"><textarea className="input-field w-full min-h-20" value={f.criteria} onChange={e=>set('criteria',e.target.value)}/></Field><Field label="교사 운영 메모"><textarea className="input-field w-full min-h-20" value={f.guidance} onChange={e=>set('guidance',e.target.value)}/></Field>{!presentationMode&&<div className="grid grid-cols-2 gap-3"><Field label="제출 단위"><select className="input-field w-full" value={f.scope} onChange={e=>{const v=e.target.value;set('scope',v);if(v==='NONE')set('requirement','NONE');else if(f.requirement==='NONE')set('requirement','REQUIRED')}}><option value="GUILD">길드 공동</option><option value="INDIVIDUAL">개인</option><option value="NONE">제출 없음</option></select></Field><Field label="제출 요구"><select className="input-field w-full" value={f.requirement} onChange={e=>set('requirement',e.target.value)}><option value="REQUIRED">필수</option><option value="OPTIONAL">선택</option><option value="NONE">없음</option></select></Field></div>}<div className="space-y-3"><div><div className="text-xs font-black text-text-muted mb-1">결과 제출 마감</div><div className="grid grid-cols-1 gap-2 sm:grid-cols-[minmax(0,1fr)_110px_110px]"><input type="date" className="input-field w-full" value={f.dueDate} onChange={e=>set('dueDate',e.target.value)}/><select className="input-field w-full" value={f.dueHour} onChange={e=>set('dueHour',e.target.value)}><option value="">시</option>{hourOptions.map(hour=><option key={hour} value={hour}>{Number(hour)}시</option>)}</select><select className="input-field w-full" value={f.dueMinute} onChange={e=>set('dueMinute',e.target.value)}><option value="">분</option>{minuteOptions.map(minute=><option key={minute} value={minute}>{Number(minute)}분</option>)}</select></div></div><div><div className="text-xs font-black text-text-muted mb-1">활동 기록 마감</div><div className="grid grid-cols-1 gap-2 sm:grid-cols-[minmax(0,1fr)_110px_110px]"><input type="date" className="input-field w-full" value={f.activityDueDate} onChange={e=>set('activityDueDate',e.target.value)}/><select className="input-field w-full" value={f.activityDueHour} onChange={e=>set('activityDueHour',e.target.value)}><option value="">시</option>{hourOptions.map(hour=><option key={hour} value={hour}>{Number(hour)}시</option>)}</select><select className="input-field w-full" value={f.activityDueMinute} onChange={e=>set('activityDueMinute',e.target.value)}><option value="">분</option>{minuteOptions.map(minute=><option key={minute} value={minute}>{Number(minute)}분</option>)}</select></div><span className="text-2xs text-text-muted">날짜/시간을 모두 비워두면 생성 시 결과 마감 +24시간이 자동 적용됩니다.</span></div></div>{!presentationMode&&<label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={f.peer} onChange={e=>set('peer',e.target.checked)}/> FINALIZED 후 Guild 4 동료평가 opening 생성</label>}{presentationMode&&<Field label="수정 사유"><input className="input-field w-full" value={f.reason} onChange={e=>set('reason',e.target.value)} placeholder="감사 이력에 기록됩니다"/></Field>}{!validCombo&&<div className="text-xs text-danger">제출 없음은 제출 단위/요구가 모두 NONE이어야 합니다.</div>}{missing.length>0&&<div className="text-xs text-warning">저장 전 확인: {missing.join(' · ')}</div>}{saveMessage&&<div role="status" aria-live="polite" className={`rounded-card-md border px-3 py-2 text-xs ${saveMessage.kind==='error'?'border-danger/40 bg-danger/10 text-danger':'border-bv/40 bg-bv/10 text-bv'}`}>{saveMessage.text}</div>}<button type="button" className="btn-primary w-full" disabled={busy} onClick={()=>void save()}>{busy?'저장 중...':'저장'}</button></div></Modal>;
}

function StateBadge({state}:{state:string}){return <span className={`text-2xs rounded-full px-2 py-1 font-black ${stateStyle[state]??'bg-bg-deep text-text-muted'}`}>{stateKo[state]??state}</span>}
function TextBox({title,text}:{title:string;text:unknown}){return <div className="rounded-card-md border border-line bg-bg-deep p-3"><div className="text-xs font-black text-text-muted">{title}</div><div className="text-sm mt-1 whitespace-pre-wrap">{String(text??'-')}</div></div>}
function Field({label,children}:{label:string;children:ReactNode}){return <label className="block"><span className="text-xs font-black text-text-muted block mb-1">{label}</span>{children}</label>}
