// =====================================================================
// B.R.A.N.D 2.0 — 인증 전역 상태 (Zustand)
// Stage 6-B · 생성일 2026-05-20
// =====================================================================
// Stage 5-B의 auth_helpers를 React에서 사용하기 위한 전역 스토어.
//
// 사용:
//   const { context, isLoading, login, logout } = useAuthStore();
// =====================================================================

import { create } from 'zustand';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase/client';
import {
  loginStudent as loginStudentApi,
  loginTeacher as loginTeacherApi,
  logout as logoutApi,
  getCurrentUserContext,
  onAuthStateChange,
  type UserContext,
  type StudentLoginParams,
  type TeacherLoginParams,
} from '@/lib/supabase/auth_helpers';
import { recordTrustedLoginEvent } from '@/lib/supabase/login_history';
import { recordAppAccessEvent } from '@/lib/supabase/app_access';

let accessVisibilityListenerInstalled = false;
let hiddenAt: number | null = null;

function installAccessVisibilityListener(): void {
  if (accessVisibilityListenerInstalled || typeof document === 'undefined') return;
  accessVisibilityListenerInstalled = true;

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      hiddenAt = Date.now();
      return;
    }
    if (document.visibilityState !== 'visible') return;

    const state = useAuthStore.getState();
    if (!state.context?.studentId || !state.session) return;

    // Preserve every app/tab return as a raw access signal.
    // The server, not the client, decides whether it begins a new 30-minute visit.
    if (hiddenAt === null) return;
    hiddenAt = null;
    void recordAppAccessEvent(supabase, 'APP_RESUME');
  });
}

// =====================================================================
// State + Actions 타입
// =====================================================================

interface AuthState {
  // State
  session: Session | null;
  user: User | null;
  context: UserContext | null;
  isLoading: boolean;
  isInitialized: boolean;
  error: string | null;

  // Actions
  initialize: () => Promise<void>;
  loginStudent: (params: StudentLoginParams) => Promise<void>;
  loginTeacher: (params: TeacherLoginParams) => Promise<void>;
  logout: () => Promise<void>;
  refreshContext: () => Promise<void>;
  clearError: () => void;
}

// =====================================================================
// 스토어 생성
// =====================================================================

// APP_CONNECTION_RECOVERY_V1: one session restoration and listener installation at a time.
let authInitializationInFlight = false;
let authStateUnsubscribe: (() => void) | null = null;

export const useAuthStore = create<AuthState>((set, get) => ({
  session: null,
  user: null,
  context: null,
  isLoading: false,
  isInitialized: false,
  error: null,

  // ---------------------------------------------------------------
  // initialize — 앱 시작 시 한 번 호출 (세션 복원)
  // ---------------------------------------------------------------
  initialize: async () => {
    if (get().isInitialized || authInitializationInFlight) return;
    authInitializationInFlight = true;

    set({ isLoading: true });
    installAccessVisibilityListener();

    try {
      // 1. 저장된 세션 조회
      const { data } = await supabase.auth.getSession();

      if (data.session) {
        // 2. 컨텍스트 조회
        try {
          const context = await getCurrentUserContext(supabase);
          set({
            session: data.session,
            user: data.session.user,
            context,
            isLoading: false,
            isInitialized: true,
            error: null,
          });

          // 비밀번호를 다시 입력하지 않은 persisted session 복원도 실제 접속이다.
          if (context.studentId) void recordAppAccessEvent(supabase, 'SESSION_RESTORE');
        } catch (e) {
          // A network timeout does not prove that the stored session expired.
          set({
            session: data.session,
            user: data.session.user,
            context: null,
            isLoading: false,
            isInitialized: true,
            error: e instanceof Error ? e.message : '서버 연결을 다시 확인해주세요.',
          });
        }
      } else {
        // 저장된 세션 없음
        set({
          isLoading: false,
          isInitialized: true,
        });
      }

      // 3. 세션 변경 자동 구독 (토큰 갱신·로그아웃 감지)
      authStateUnsubscribe?.();
      authStateUnsubscribe = onAuthStateChange(supabase, async (newSession) => {
        if (newSession) {
          if (get().session?.user.id === newSession.user.id && get().context) {
            set({ session: newSession, user: newSession.user });
            return;
          }
          try {
            const context = await getCurrentUserContext(supabase);
            set({
              session: newSession,
              user: newSession.user,
              context,
            });

          } catch {
            // 컨텍스트 조회 실패
            set({
              session: null,
              user: null,
              context: null,
            });
          }
        } else {
          set({
            session: null,
            user: null,
            context: null,
          });
        }
      });
    } catch (e) {
      set({
        isLoading: false,
        isInitialized: true,
        error: e instanceof Error ? e.message : '초기화 실패',
      });
    } finally {
      authInitializationInFlight = false;
    }
  },

  // ---------------------------------------------------------------
  // 학생 로그인
  // ---------------------------------------------------------------
  loginStudent: async (params) => {
    set({ isLoading: true, error: null });

    try {
      const result = await loginStudentApi(supabase, params);
      void recordTrustedLoginEvent(supabase, 'LOGIN_SUCCESS');
      void recordAppAccessEvent(supabase, 'EXPLICIT_LOGIN');
      set({
        session: result.session,
        user: result.user,
        context: result.context,
        isLoading: false,
        error: null,
      });
    } catch (e) {
      set({
        isLoading: false,
        error: e instanceof Error ? e.message : '로그인 실패',
      });
      throw e;
    }
  },

  // ---------------------------------------------------------------
  // 교사 로그인
  // ---------------------------------------------------------------
  loginTeacher: async (params) => {
    set({ isLoading: true, error: null });

    try {
      const result = await loginTeacherApi(supabase, params);
      void recordTrustedLoginEvent(supabase, 'LOGIN_SUCCESS');
      set({
        session: result.session,
        user: result.user,
        context: result.context,
        isLoading: false,
        error: null,
      });
    } catch (e) {
      set({
        isLoading: false,
        error: e instanceof Error ? e.message : '로그인 실패',
      });
      throw e;
    }
  },

  // ---------------------------------------------------------------
  // 로그아웃
  // ---------------------------------------------------------------
  logout: async () => {
    set({ isLoading: true });

    try {
      // 세션이 사라지기 전에 best-effort로 로그아웃 이벤트를 남긴다.
      await recordTrustedLoginEvent(supabase, 'LOGOUT');
      await logoutApi(supabase);
      set({
        session: null,
        user: null,
        context: null,
        isLoading: false,
        error: null,
      });
    } catch (e) {
      set({
        isLoading: false,
        error: e instanceof Error ? e.message : '로그아웃 실패',
      });
    }
  },

  // ---------------------------------------------------------------
  // 컨텍스트 새로고침 (티어 변경 등 후)
  // ---------------------------------------------------------------
  refreshContext: async () => {
    if (!get().session) return;

    try {
      const context = await getCurrentUserContext(supabase);
      set({ context });
    } catch (e) {
      console.error('Context refresh failed:', e);
    }
  },

  // ---------------------------------------------------------------
  // 에러 초기화
  // ---------------------------------------------------------------
  clearError: () => set({ error: null }),
}));

// =====================================================================
// 편의 selectors
// =====================================================================

export const useIsAuthenticated = () => useAuthStore((s) => s.session !== null);
export const useCurrentStudent = () => {
  const context = useAuthStore((s) => s.context);
  const userId = useAuthStore((s) => s.user?.id ?? null);

  return context
    ? {
        ...context,
        userId,
      }
    : null;
};
export const useIsTeacher = () => useAuthStore((s) => s.context?.isTeacher ?? false);
export const useStudentId = () => useAuthStore((s) => s.context?.studentId ?? null);
export const useClassroomId = () => useAuthStore((s) => s.context?.classroomId ?? null);
