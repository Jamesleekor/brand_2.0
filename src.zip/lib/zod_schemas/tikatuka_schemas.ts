import { z } from 'zod';

export const TikatukaDifficultySchema = z.union([
  z.literal(1), z.literal(2), z.literal(3), z.literal(4), z.literal(5),
  z.literal(6), z.literal(7), z.literal(8), z.literal(9), z.literal(10),
]);
export type TikatukaDifficulty = z.infer<typeof TikatukaDifficultySchema>;
export const TikatukaWinnerSchema = z.enum(['player', 'ai', 'draw']);

export const TikatukaProgressSchema = z.object({
  highest_unlocked_difficulty: TikatukaDifficultySchema,
  cleared_difficulties: z.array(TikatukaDifficultySchema),
  games_played: z.number().int().nonnegative(),
  wins: z.number().int().nonnegative(),
  losses: z.number().int().nonnegative(),
  draws: z.number().int().nonnegative(),
  last_played_at: z.string().datetime({ offset: true }).nullable(),
}).strict();
export type TikatukaProgress = z.infer<typeof TikatukaProgressSchema>;

export const TeacherTikatukaProgressItemSchema = TikatukaProgressSchema.extend({
  student_id: z.number().int().positive(),
  student_name: z.string().min(1),
  brand_name: z.string().nullable(),
}).strict();
export type TeacherTikatukaProgressItem = z.infer<typeof TeacherTikatukaProgressItemSchema>;

export const TeacherTikatukaOfficialChallengeSchema = z.object({
  session_id: z.number().int().positive(),
  status: z.enum(['ACTIVE', 'COMPLETED']),
  difficulty: TikatukaDifficultySchema,
  games_played: z.number().int().min(0).max(5),
  wins: z.number().int().min(0).max(5),
  draws: z.number().int().min(0).max(5),
  losses: z.number().int().min(0).max(5),
  points: z.number().int().min(0).max(15),
  results: z.array(TikatukaWinnerSchema).max(5),
  started_at: z.string().datetime({ offset: true }),
  completed_at: z.string().datetime({ offset: true }).nullable(),
}).strict();
export type TeacherTikatukaOfficialChallenge = z.infer<typeof TeacherTikatukaOfficialChallengeSchema>;

export const TeacherTikatukaProgressListItemSchema = TeacherTikatukaProgressItemSchema.extend({
  recent_results: z.array(TikatukaWinnerSchema).max(5),
  official_challenge: TeacherTikatukaOfficialChallengeSchema.nullable(),
}).strict();
export type TeacherTikatukaProgressListItem = z.infer<typeof TeacherTikatukaProgressListItemSchema>;

export const TeacherTikatukaProgressListSchema = z.object({
  items: z.array(TeacherTikatukaProgressListItemSchema),
}).strict();
export type TeacherTikatukaProgressList = z.infer<typeof TeacherTikatukaProgressListSchema>;

export const TeacherSetTikatukaProgressSchema = z.object({
  p_student_id: z.number().int().positive(),
  p_highest_unlocked_difficulty: TikatukaDifficultySchema,
}).strict();
export type TeacherSetTikatukaProgressInput = z.infer<typeof TeacherSetTikatukaProgressSchema>;

export const StudentCreateTikatukaGameSchema = z.object({
  p_difficulty: TikatukaDifficultySchema,
}).strict();
export type StudentCreateTikatukaGameInput = z.infer<typeof StudentCreateTikatukaGameSchema>;

export const TikatukaIssuedGameSchema = z.object({
  game_id: z.string().uuid(),
  engine_version: z.literal(1),
  difficulty: TikatukaDifficultySchema,
  issued_at: z.string().datetime({ offset: true }),
  progress: TikatukaProgressSchema,
}).strict();
export type TikatukaIssuedGame = z.infer<typeof TikatukaIssuedGameSchema>;

export const TikatukaFinalDieSchema = z.object({
  value: z.number().int().min(1).max(6),
  kind: z.enum(['normal', 'shield']),
}).strict();
export type TikatukaFinalDie = z.infer<typeof TikatukaFinalDieSchema>;

export const TikatukaFinalRowSchema = z.tuple([
  TikatukaFinalDieSchema,
  TikatukaFinalDieSchema,
  TikatukaFinalDieSchema,
]);
export type TikatukaFinalRow = z.infer<typeof TikatukaFinalRowSchema>;

export const TikatukaFinalBoardSchema = z.object({
  top: TikatukaFinalRowSchema,
  middle: TikatukaFinalRowSchema,
  bottom: TikatukaFinalRowSchema,
}).strict();
export type TikatukaFinalBoard = z.infer<typeof TikatukaFinalBoardSchema>;

export const TikatukaFinalBoardsSchema = z.object({
  player: TikatukaFinalBoardSchema,
  ai: TikatukaFinalBoardSchema,
}).strict();
export type TikatukaFinalBoards = z.infer<typeof TikatukaFinalBoardsSchema>;

const NonNegativeCounter = z.number().int().nonnegative();

export const StudentSubmitTikatukaResultSchema = z.object({
  p_game_id: z.string().uuid(),
  p_engine_version: z.literal(1),
  p_winner: TikatukaWinnerSchema,
  p_difficulty: TikatukaDifficultySchema,
  p_player_row_wins: z.number().int().min(0).max(3),
  p_ai_row_wins: z.number().int().min(0).max(3),
  p_tied_rows: z.number().int().min(0).max(3),
  p_player_score: z.number().int().min(0).max(90),
  p_ai_score: z.number().int().min(0).max(90),
  p_player_raw_pips: z.number().int().min(0).max(54),
  p_ai_raw_pips: z.number().int().min(0).max(54),
  p_player_knock_count: NonNegativeCounter,
  p_ai_knock_count: NonNegativeCounter,
  p_player_dice_removed: NonNegativeCounter,
  p_ai_dice_removed: NonNegativeCounter,
  p_player_shields_earned: NonNegativeCounter,
  p_ai_shields_earned: NonNegativeCounter,
  p_player_tazza_used: NonNegativeCounter,
  p_ai_tazza_used: NonNegativeCounter,
  p_player_hold_used: NonNegativeCounter,
  p_ai_hold_used: NonNegativeCounter,
  p_total_turns: z.number().int().min(18).max(5000),
  p_final_boards: TikatukaFinalBoardsSchema,
}).strict().superRefine((value, ctx) => {
  if (value.p_player_row_wins + value.p_ai_row_wins + value.p_tied_rows !== 3) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['p_tied_rows'],
      message: 'Row 승/패/무 합계는 3이어야 합니다.',
    });
  }
});
export type StudentSubmitTikatukaResultInput = z.infer<typeof StudentSubmitTikatukaResultSchema>;

export const TikatukaServerResultSchema = z.object({
  winner: TikatukaWinnerSchema,
  difficulty: TikatukaDifficultySchema,
  player_row_wins: z.number().int().min(0).max(3),
  ai_row_wins: z.number().int().min(0).max(3),
  tied_rows: z.number().int().min(0).max(3),
  player_score: z.number().int().min(0).max(90),
  ai_score: z.number().int().min(0).max(90),
  player_raw_pips: z.number().int().min(0).max(54),
  ai_raw_pips: z.number().int().min(0).max(54),
  player_knock_count: NonNegativeCounter,
  ai_knock_count: NonNegativeCounter,
  player_dice_removed: NonNegativeCounter,
  ai_dice_removed: NonNegativeCounter,
  player_shields_earned: NonNegativeCounter,
  ai_shields_earned: NonNegativeCounter,
  player_tazza_used: NonNegativeCounter,
  ai_tazza_used: NonNegativeCounter,
  player_hold_used: NonNegativeCounter,
  ai_hold_used: NonNegativeCounter,
  total_turns: z.number().int().min(18).max(5000),
}).strict();
export type TikatukaServerResult = z.infer<typeof TikatukaServerResultSchema>;

export const TikatukaSubmissionResponseSchema = z.object({
  accepted: z.literal(true),
  duplicate: z.boolean(),
  game_id: z.string().uuid(),
  server_winner: TikatukaWinnerSchema,
  server_result: TikatukaServerResultSchema,
  progress: TikatukaProgressSchema,
}).strict();
export type TikatukaSubmissionResponse = z.infer<typeof TikatukaSubmissionResponseSchema>;
